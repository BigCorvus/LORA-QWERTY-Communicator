#pragma once

#include "configuration.h"

#include "detect/ScanI2C.h"
#include "mesh/generated/meshtastic/config.pb.h"
#include <OLEDDisplay.h>
#include <atomic>
#include <functional>
#include <memory>
#include <string>
#include <vector>

#define getStringCenteredX(s) ((SCREEN_WIDTH - display->getStringWidth(s)) / 2)
namespace graphics
{
enum notificationTypeEnum {
    none,
    text_banner,
    selection_picker,
    node_picker,
    number_picker,
    hex_picker,
    text_input,
    // BLE pairing PIN banner. Treated specially by the lockdown short-circuit
    // in Screen.cpp: the PIN is ephemeral (regenerated per pair attempt) and
    // not a real secret, so we allow ui->update() to composite it over the
    // LOCKED frame. Without this, a first-pair on a locked device cannot
    // complete because the PIN never renders.
    pairing_pin,
    // Arcade-style initials entry: like number_picker/hex_picker, but each position cycles
    // through A-Z and 0-9. The assembled string is returned via a text (std::string) callback.
    alphanumeric_picker,
};

struct BannerOverlayOptions {
    const char *message;
    uint32_t durationMs = 30000;
    const char **optionsArrayPtr = nullptr;
    const int *optionsEnumPtr = nullptr;
    uint8_t optionsCount = 0;
    // Plain function pointer (captureless lambdas convert); only one banner is live, so keep any state in statics.
    void (*bannerCallback)(int) = nullptr;
    int8_t InitialSelected = 0;
    notificationTypeEnum notificationType = notificationTypeEnum::text_banner;
};
} // namespace graphics

bool shouldWakeOnReceivedMessage();

class MeshModule;

#if !HAS_SCREEN
#include "Power.h"
namespace graphics
{
// Noop class for boards without screen.
class Screen
{
  public:
    enum FrameFocus : uint8_t {
        FOCUS_DEFAULT,  // No specific frame
        FOCUS_PRESERVE, // Return to the previous frame
        FOCUS_FAULT,
        FOCUS_MODULE, // Note: target module should call requestFocus(), otherwise no info about which module to focus
        FOCUS_CLOCK,
        FOCUS_SYSTEM,
    };

    explicit Screen(ScanI2C::DeviceAddress, meshtastic_Config_DisplayConfig_OledType, OLEDDISPLAY_GEOMETRY);
    // These are empty stubs, but they mirror the real Screen's instance API, so they can't become static.
    // cppcheck-suppress-begin functionStatic
    void onPress() {}
    void setup() {}
    void setOn(bool) {}
    void doDeepSleep() {}
    void forceDisplay(bool forceUiUpdate = false) {}
    void startFirmwareUpdateScreen() {}
    void increaseBrightness() {}
    void decreaseBrightness() {}
    void startAlert(const char *) {}
    void setModalModule(const MeshModule *) {}
    void clearModalModule(const MeshModule *) {}
    bool hasModalModule() const { return false; }
    bool isShowingModuleFrame(const MeshModule *) const { return false; }
    void showSimpleBanner(const char *message, uint32_t durationMs = 0) {}
    void showOverlayBanner(const BannerOverlayOptions &) {}
    void setFrames(FrameFocus focus) {}
    void endAlert() {}
    bool getIsI2cScreen() const { return false; }
    uint32_t getI2cFrequency() const { return 0; }
    ScanI2C::I2CPort getI2CPort() const { return ScanI2C::I2CPort::NO_I2C; }
    // cppcheck-suppress-end functionStatic
};
} // namespace graphics
#else
#include <cstring>

#include <OLEDDisplayUi.h>

#include "../configuration.h"
#include "gps/GeoCoord.h"
#include "graphics/ScreenFonts.h"

#ifdef USE_ST7567
#include <ST7567Wire.h>
#elif defined(USE_SHARP_MEMORY_LCD)
#include "SharpMemoryDisplay.h"
#elif defined(USE_SH1106) || defined(USE_SH1107) || defined(USE_SH1107_128_64)
#include <SH1106Wire.h>
#elif defined(USE_SSD1306)
#include <SSD1306Wire.h>
#elif defined(USE_ST7789)
#include <ST7789Spi.h>
#elif defined(USE_SPISSD1306)
#include <SSD1306Spi.h>
#elif defined(USE_ST7796)
#include <ST7796Spi.h>
#else
// the SH1106/SSD1306 variant is auto-detected
#include <AutoOLEDWire.h>
#endif

#if defined(MESHTASTIC_INCLUDE_NICHE_GRAPHICS) && !defined(MESHTASTIC_INCLUDE_INKHUD)
// NicheGraphics-backed BaseUI e-ink stack; supplies the EINK_* compat macros for converted variants.
// InkHUD builds keep the legacy includes: their TUs carry InkHUD's own NicheGraphics::Drivers classes,
// which would collide with graphics/eink/ declarations until InkHUD moves onto the shared layer.
#include "BaseUIEInkDisplay.h"
#else
#include "EInkDisplay2.h"
#include "EInkDynamicDisplay.h"
#endif
#include "PointStruct.h"
#include "Power.h"
#include "TFTDisplay.h"
#include "TypedQueue.h"
#include "commands.h"
#include "concurrency/LockGuard.h"
#include "concurrency/OSThread.h"
#include "graphics/draw/MenuHandler.h"
#include "input/InputBroker.h"
#include "mesh/MeshModule.h"
#include "modules/AdminModule.h"
#include <string>
#include <vector>

// 0 to 255, though particular variants might define different defaults
#ifndef BRIGHTNESS_DEFAULT
#define BRIGHTNESS_DEFAULT 150
#endif

// Meters to feet conversion
#ifndef METERS_TO_FEET
#define METERS_TO_FEET 3.28
#endif

// Feet to miles conversion
#ifndef MILES_TO_FEET
#define MILES_TO_FEET 5280
#endif

// Intuitive colors. E-Ink display is inverted from OLED(?)
#define EINK_BLACK OLEDDISPLAY_COLOR::WHITE
#define EINK_WHITE OLEDDISPLAY_COLOR::BLACK

// Base segment dimensions for T-Watch segmented display
#define SEGMENT_WIDTH 16
#define SEGMENT_HEIGHT 4

/// Convert an integer GPS coords to a floating point
#define DegD(i) (i * 1e-7)
extern bool hasUnreadMessage;
namespace
{
/// A basic 2D point class for drawing
class Point
{
  public:
    float x, y;

    Point(float _x, float _y) : x(_x), y(_y) {}

    /// Apply a rotation around zero (standard rotation matrix math)
    void rotate(float radian)
    {
        float cos = cosf(radian), sin = sinf(radian);
        float rx = x * cos + y * sin, ry = -x * sin + y * cos;

        x = rx;
        y = ry;
    }

    void translate(int16_t dx, int dy)
    {
        x += dx;
        y += dy;
    }

    void scale(float f)
    {
        // We use -f here to counter the flip that happens
        // on the y axis when drawing and rotating on screen
        x *= f;
        y *= -f;
    }
};

} // namespace

namespace graphics
{

enum class FrameDirection { NEXT, PREVIOUS };

// Forward declarations
class Screen;

/**
 * @brief This class deals with showing things on the screen of the device.
 *
 * @details Other than setup(), this class is thread-safe as long as drawFrame is not called
 *          multiple times simultaneously. All state-changing calls are queued and executed
 *          when the main loop calls us.
 */
class Screen : public concurrency::OSThread
{
    CallbackObserver<Screen, const meshtastic::Status *> powerStatusObserver =
        CallbackObserver<Screen, const meshtastic::Status *>(this, &Screen::handleStatusUpdate);
    CallbackObserver<Screen, const meshtastic::Status *> gpsStatusObserver =
        CallbackObserver<Screen, const meshtastic::Status *>(this, &Screen::handleStatusUpdate);
    CallbackObserver<Screen, const meshtastic::Status *> nodeStatusObserver =
        CallbackObserver<Screen, const meshtastic::Status *>(this, &Screen::handleStatusUpdate);
    CallbackObserver<Screen, const UIFrameEvent *> uiFrameEventObserver =
        CallbackObserver<Screen, const UIFrameEvent *>(this, &Screen::handleUIFrameEvent); // Sent by Mesh Modules
    CallbackObserver<Screen, const InputEvent *> inputObserver =
        CallbackObserver<Screen, const InputEvent *>(this, &Screen::handleInputEvent);
    CallbackObserver<Screen, AdminModule_ObserverData *> adminMessageObserver =
        CallbackObserver<Screen, AdminModule_ObserverData *>(this, &Screen::handleAdminMessage);

  public:
    OLEDDisplay *getDisplayDevice() { return dispdev; }
    explicit Screen(ScanI2C::DeviceAddress, meshtastic_Config_DisplayConfig_OledType, OLEDDISPLAY_GEOMETRY);

    // Screen dimension accessors
    inline int getHeight() const { return displayHeight; }
    inline int getWidth() const { return displayWidth; }
    size_t frameCount = 0; // Total number of active frames
    ~Screen();

    // Which frame we want to be displayed, after we regen the frameset by calling setFrames
    enum FrameFocus : uint8_t {
        FOCUS_DEFAULT,  // No specific frame
        FOCUS_PRESERVE, // Return to the previous frame
        FOCUS_FAULT,
        FOCUS_MODULE, // Note: target module should call requestFocus(), otherwise no info about which module to focus
        FOCUS_CLOCK,
        FOCUS_SYSTEM,
    };

    // Regenerate the normal set of frames, focusing a specific frame if requested
    // Call when a frame should be added / removed, or custom frames should be cleared
    void setFrames(FrameFocus focus = FOCUS_DEFAULT);

    std::vector<const uint8_t *> indicatorIcons; // Per-frame custom icon pointers
#if defined(OLED_COMPACT_UI)
    std::vector<const char *> frameTitles; // Per-frame short labels, parallel to indicatorIcons
#endif
    Screen(const Screen &) = delete;
    Screen &operator=(const Screen &) = delete;

    ScanI2C::DeviceAddress address_found;
    bool getIsI2cScreen() const { return isI2cScreen; }
    // Return I2C Speed, or 0 if none
    uint32_t getI2cFrequency() const
    {
        if (getIsI2cScreen())
            return dispdev->getI2cFrequency();
        else
            return 0;
    }
    ScanI2C::I2CPort getI2CPort() const
    {
        if (getIsI2cScreen())
            return address_found.port;
        else
            return ScanI2C::I2CPort::NO_I2C;
    }
    meshtastic_Config_DisplayConfig_OledType model;
    OLEDDISPLAY_GEOMETRY geometry;

    bool isOverlayBannerShowing();

    // Thread-safe snapshot of whether the text-message frame is currently shown.
    bool isTextMessageFrameShown() const;

    // True if the always-present games frame is the one currently on screen. Lets the games module
    // ignore D-pad input when the player has navigated to a different frame.
    bool isGamesFrameShown();

    // Jump straight to the home (device-focused) frame. Used to bounce back to a clearly "this is a
    // Meshtastic node" screen after a game is left idle. Home is optional, so when it is hidden this
    // falls back to the messages frame rather than staying put.
    void showHomeFrame();

    // True when the user is in the middle of something that must not be interrupted: a module (or
    // game) is holding the D-pad, or an interactive overlay (picker / text entry) is open. Callers
    // that would pop a transient banner should check this first -- a banner both covers the screen
    // and REPLACES any interactive overlay, discarding a half-finished entry.
    bool isInteractionBusy();

    bool isScreenOn() { return screenOn; }

    // Stores the last 4 of our hardware ID, to make finding the device for pairing easier
    // FIXME: Needs refactoring and getMacAddr needs to be moved to a utility class
    char ourId[5];

    // if we have a step counter, this stores the number of steps.
    uint32_t steps = 0;

    /// Initializes the UI, turns on the display, starts showing boot screen.
    //
    // Not thread safe - must be called before any other methods are called.
    void setup();

    /// Turns the screen on/off. Optionally, pass a custom screensaver frame for E-Ink
    void setOn(bool on, FrameCallback einkScreensaver = NULL);
    /**
     * Prepare the display for the unit going to the lowest power mode possible.  Most screens will just
     * poweroff, but eink screens will show a "I'm sleeping" graphic, possibly with a QR code
     */
    void doDeepSleep();

    // Draw north
    float estimatedHeading(double lat, double lon);

    /// Handle button press, trackball or swipe action)
    void onPress() { enqueueCmd(ScreenCmd{.cmd = Cmd::ON_PRESS}); }
    void showPrevFrame() { enqueueCmd(ScreenCmd{.cmd = Cmd::SHOW_PREV_FRAME}); }
    void showNextFrame() { enqueueCmd(ScreenCmd{.cmd = Cmd::SHOW_NEXT_FRAME}); }
    void showFrame(FrameDirection direction);

    // generic alert start
    void startAlert(FrameCallback _alertFrame)
    {
        alertFrame = _alertFrame;
        ScreenCmd cmd;
        cmd.cmd = Cmd::START_ALERT_FRAME;
        enqueueCmd(cmd);
    }

    void startAlert(const char *_alertMessage)
    {
        startAlert([_alertMessage](OLEDDisplay *display, OLEDDisplayUiState *state, int16_t x, int16_t y) -> void {
            uint16_t x_offset = display->width() / 2;
            display->setTextAlignment(TEXT_ALIGN_CENTER);
            display->setFont(FONT_MEDIUM);
            display->drawString(x_offset + x, 26 + y, _alertMessage);
        });
    }

    void endAlert()
    {
        ScreenCmd cmd;
        cmd.cmd = Cmd::STOP_ALERT_FRAME;
        enqueueCmd(cmd);
    }

    // Holds the screen against the carousel, the new-message banner and a foreign endAlert().
    // Only the owner can release it, unlike endAlert(), which any caller can fire.
    void setModalModule(const MeshModule *owner) { modalModule = owner; }
    void clearModalModule(const MeshModule *owner)
    {
        if (modalModule == owner)
            modalModule = nullptr;
    }
    bool hasModalModule() const { return modalModule != nullptr; }

    // True while this module's own frame is on screen. Modules observe input before Screen does,
    // so one handling keys needs this or it takes them from the frame the user is looking at.
    bool isShowingModuleFrame(const MeshModule *m) const;

    void showSimpleBanner(const char *message, uint32_t durationMs = 0);
    void showOverlayBanner(const BannerOverlayOptions &banner_overlay_options);

    void showNodePicker(const char *message, uint32_t durationMs, std::function<void(uint32_t)> bannerCallback);
    void showNumberPicker(const char *message, uint32_t durationMs, uint8_t digits, bool useBase16,
                          std::function<void(uint32_t)> bannerCallback);
    // Arcade-style initials entry. `length` positions each cycle A-Z/0-9 (UP/DOWN), LEFT/RIGHT
    // moves the cursor, SELECT advances; the assembled string is delivered to `bannerCallback`.
    // `initialText` pre-seeds the positions (uppercased & filtered), defaulting to 'A'.
    void showAlphanumericPicker(const char *message, const char *initialText, uint32_t durationMs, uint8_t length,
                                std::function<void(const std::string &)> bannerCallback);
    void showTextInput(const char *header, const char *initialText, uint32_t durationMs,
                       std::function<void(const std::string &)> textCallback);

    void requestMenu(graphics::menuHandler::screenMenus menuToShow)
    {
        graphics::menuHandler::menuQueue = menuToShow;
        runNow();
    }

    void startFirmwareUpdateScreen()
    {
        ScreenCmd cmd;
        cmd.cmd = Cmd::START_FIRMWARE_UPDATE_SCREEN;
        enqueueCmd(cmd);
    }

    // Function to allow the AccelerometerThread to set the heading if a sensor provides it
    // Mutex needed?
    void setHeading(float heading);

    bool hasHeading() { return hasCompass; }

    float getHeading() { return compassHeading; }

    void setEndCalibration(uint32_t _endCalibrationAt) { endCalibrationAt = _endCalibrationAt; }
    uint32_t getEndCalibration() { return endCalibrationAt; }

    // functions for display brightness
    void increaseBrightness();
    void decreaseBrightness();

    /// Stops showing the boot screen.
    void stopBootScreen() { enqueueCmd(ScreenCmd{.cmd = Cmd::STOP_BOOT_SCREEN}); }

    void runNow()
    {
        setFastFramerate();
        enqueueCmd(ScreenCmd{.cmd = Cmd::NOOP});
    }

    /// Overrides the default utf8 character conversion, to replace empty space with question marks
    static char customFontTableLookup(const uint8_t ch)
    {
        // UTF-8 to font table index converter
        // Code from http://playground.arduino.cc/Main/Utf8ascii
        static uint8_t LASTCHAR;
        static bool SKIPREST; // Only display a single unconvertable-character symbol per sequence of unconvertable characters

        if (ch < 128) { // Standard ASCII-set 0..0x7F handling
            LASTCHAR = 0;
            SKIPREST = false;
            return ch;
        }

        uint8_t last = LASTCHAR; // get last char
        LASTCHAR = ch;

        switch (last) {
        case 0xC2: {
            SKIPREST = false;
            return (uint8_t)ch;
        }

        case 0xC3: {
            SKIPREST = false;
            return (uint8_t)(ch | 0xC0);
        }
        }

        // We want to strip out prefix chars for two-byte char formats
        if (ch == 0xC2 || ch == 0xC3)
            return (uint8_t)0;

#if defined(OLED_PL)

        switch (last) {
        case 0xC3: {

            if (ch == 147)
                return (uint8_t)(ch); // Ó
            else if (ch == 179)
                return (uint8_t)(148); // ó
            else
                return (uint8_t)(ch | 0xC0);
            break;
        }

        case 0xC4: {
            SKIPREST = false;
            return (uint8_t)(ch);
        }

        case 0xC5: {
            SKIPREST = false;
            if (ch == 132)
                return (uint8_t)(136); // ń
            else if (ch == 186)
                return (uint8_t)(137); // ź
            else
                return (uint8_t)(ch);
            break;
        }
        }

        // We want to strip out prefix chars for two-byte char formats
        if (ch == 0xC2 || ch == 0xC3 || ch == 0xC4 || ch == 0xC5)
            return (uint8_t)0;

#endif

#if defined(OLED_UA) || defined(OLED_RU)

        switch (last) {
        case 0xC3: {
            SKIPREST = false;
            return (uint8_t)(ch | 0xC0);
        }
        // map UTF-8 cyrillic chars to it Windows-1251 (CP-1251) ASCII codes
        // note: in this case we must use compatible font - provided ArialMT_Plain_10/16/24 by 'ThingPulse/esp8266-oled-ssd1306'
        // library have empty chars for non-latin ASCII symbols
        case 0xD0: {
            SKIPREST = false;
            if (ch == 132)
                return (uint8_t)(170); // Є
            if (ch == 134)
                return (uint8_t)(178); // І
            if (ch == 135)
                return (uint8_t)(175); // Ї
            if (ch == 129)
                return (uint8_t)(168); // Ё
            if (ch > 143 && ch < 192)
                return (uint8_t)(ch + 48);
            break;
        }
        case 0xD1: {
            SKIPREST = false;
            if (ch == 148)
                return (uint8_t)(186); // є
            if (ch == 150)
                return (uint8_t)(179); // і
            if (ch == 151)
                return (uint8_t)(191); // ї
            if (ch == 145)
                return (uint8_t)(184); // ё
            if (ch > 127 && ch < 144)
                return (uint8_t)(ch + 112);
            break;
        }
        case 0xD2: {
            SKIPREST = false;
            if (ch == 144)
                return (uint8_t)(165); // Ґ
            if (ch == 145)
                return (uint8_t)(180); // ґ
            break;
        }
        }

        // We want to strip out prefix chars for two-byte char formats
        if (ch == 0xC2 || ch == 0xC3 || ch == 0x82 || ch == 0xD0 || ch == 0xD1)
            return (uint8_t)0;

#endif

#if defined(OLED_CS)

        switch (last) {
        case 0xC2: {
            SKIPREST = false;
            return (uint8_t)ch;
        }

        case 0xC3: {
            SKIPREST = false;
            return (uint8_t)(ch | 0xC0);
        }

        case 0xC4: {
            SKIPREST = false;
            if (ch == 140)
                return (uint8_t)(129); // Č
            if (ch == 141)
                return (uint8_t)(138); // č
            if (ch == 142)
                return (uint8_t)(130); // Ď
            if (ch == 143)
                return (uint8_t)(139); // ď
            if (ch == 154)
                return (uint8_t)(131); // Ě
            if (ch == 155)
                return (uint8_t)(140); // ě
            // Slovak specific glyphs
            if (ch == 185)
                return (uint8_t)(147); // Ĺ
            if (ch == 186)
                return (uint8_t)(148); // ĺ
            if (ch == 189)
                return (uint8_t)(149); // Ľ
            if (ch == 190)
                return (uint8_t)(150); // ľ
            break;
        }

        case 0xC5: {
            SKIPREST = false;
            if (ch == 135)
                return (uint8_t)(132); // Ň
            if (ch == 136)
                return (uint8_t)(141); // ň
            if (ch == 152)
                return (uint8_t)(133); // Ř
            if (ch == 153)
                return (uint8_t)(142); // ř
            if (ch == 160)
                return (uint8_t)(134); // Š
            if (ch == 161)
                return (uint8_t)(143); // š
            if (ch == 164)
                return (uint8_t)(135); // Ť
            if (ch == 165)
                return (uint8_t)(144); // ť
            if (ch == 174)
                return (uint8_t)(136); // Ů
            if (ch == 175)
                return (uint8_t)(145); // ů
            if (ch == 189)
                return (uint8_t)(137); // Ž
            if (ch == 190)
                return (uint8_t)(146); // ž
            // Slovak specific glyphs
            if (ch == 148)
                return (uint8_t)(151); // Ŕ
            if (ch == 149)
                return (uint8_t)(152); // ŕ
            break;
        }
        }

        // We want to strip out prefix chars for two-byte char formats
        if (ch == 0xC2 || ch == 0xC3 || ch == 0xC4 || ch == 0xC5)
            return (uint8_t)0;

#endif

#if defined(OLED_GR)

        switch (last) {
        case 0xC3: {
            SKIPREST = false;
            return (uint8_t)(ch | 0xC0);
        }
        // Map UTF-8 Greek chars to Windows-1253 (CP-1253) ASCII codes
        case 0xCE: {
            SKIPREST = false;
            // Uppercase Greek: Α-Ρ (U+0391-U+03A1) -> CP-1253 193-209
            if (ch >= 145 && ch <= 161)
                return (uint8_t)(ch + 48);
            // Uppercase Greek: Σ-Ω (U+03A3-U+03A9) -> CP-1253 211-217
            else if (ch >= 163 && ch <= 169)
                return (uint8_t)(ch + 48);
            // Lowercase Greek: α-ρ (U+03B1-U+03C1) -> CP-1253 225-241
            else if (ch >= 177 && ch <= 193)
                return (uint8_t)(ch + 48);
            break;
        }
        case 0xCF: {
            SKIPREST = false;
            // Lowercase Greek: ς-ω (U+03C2-U+03C9) -> CP-1253 242-249
            if (ch >= 130 && ch <= 137)
                return (uint8_t)(ch + 112);
            break;
        }
        }

        // We want to strip out prefix chars for two-byte Greek char formats
        if (ch == 0xC2 || ch == 0xC3 || ch == 0xCE || ch == 0xCF)
            return (uint8_t)0;

#endif

        // If we already returned an unconvertable-character symbol for this unconvertable-character sequence, return NULs for the
        // rest of it
        if (SKIPREST)
            return (uint8_t)0;
        SKIPREST = true;

        return (uint8_t)191; // otherwise: return ¿ if character can't be converted (note that the font map we're using doesn't
                             // stick to standard EASCII codes)
    }

    // Handle observer events
    int handleStatusUpdate(const meshtastic::Status *arg);
    int handleUIFrameEvent(const UIFrameEvent *arg);
    int handleInputEvent(const InputEvent *arg);
    int handleAdminMessage(AdminModule_ObserverData *arg);

    /// Used to force (super slow) eink displays to draw critical frames
    void forceDisplay(bool forceUiUpdate = false);

    /// Draws our SSL cert screen during boot (called from WebServer)
    void setSSLFrames();

    // Menu-driven Show / Hide Toggle
    void toggleFrameVisibility(const std::string &frameName);
    bool isFrameHidden(const std::string &frameName) const;

    // Persist / restore which frames are hidden, across reboots.
    // Stored as a single uint32 bitmask in /prefs (see Screen.cpp for the format).
    void loadFrameVisibility();
    void saveFrameVisibility();

#ifdef USE_EINK
    /// Draw an image to remain on E-Ink display after screen off
    void setScreensaverFrames(FrameCallback einkScreensaver = NULL);
#endif

  protected:
    /// Updates the UI.
    //
    // Called periodically from the main loop.
    int32_t runOnce() final;

    bool isAUTOOled = false;
    bool isI2cScreen = false;

    // Screen dimensions (for convenience)
    // Defined during Screen::setup
    uint16_t displayWidth = 0;
    uint16_t displayHeight = 0;

  private:
    // nullptr for every build with no modal module, which is why the three sites are unchanged.
    const MeshModule *modalModule = nullptr;

    FrameCallback alertFrames[1];
    struct ScreenCmd {
        Cmd cmd;
        union {
            uint32_t bluetooth_pin;
            char *print_text;
        };
    };

    /// Enques given command item to be processed by main loop().
    bool enqueueCmd(const ScreenCmd &cmd)
    {
        if (!useDisplay)
            return false; // not enqueued if our display is not in use
        else {
            bool success = cmdQueue.enqueue(cmd, 0);
            enabled = true; // handle ASAP (we are the registered reader for cmdQueue, but might have been disabled)
            return success;
        }
    }

    // Implementations of various commands, called from doTask().
    void handleSetOn(bool on, FrameCallback einkScreensaver = NULL);
    void handleOnPress();
    void handleStartFirmwareUpdateScreen();

#ifdef USERPREFS_UI_TEST_LOG
    // Test-only: emits one LOG_INFO line on every frame transition so the
    // pytest harness can assert which frame is shown. Gated behind a macro
    // so the chatty log doesn't ship in release builds. Enabled via
    // build_testing_profile(enable_ui_log=True) in the meshtastic-mcp harness
    // (https://github.com/meshtastic/meshtastic-mcp).
    // Member function (not free) because FramesetInfo is a private nested
    // type - only methods of Screen can reach it.
    void logFrameChange(const char *reason, uint8_t targetIdx);
#endif

    // Info collected by setFrames method.
    // Index location of specific frames.
    // - Used to apply the FrameFocus parameter of setFrames
    // - Used to dismiss the currently shown frame (txt; waypoint) by CardKB combo
    struct FramesetInfo {
        struct FramePositions {
            uint8_t fault = 255;
            uint8_t waypoint = 255;
            uint8_t focusedModule = 255;
            uint8_t log = 255;
            uint8_t settings = 255;
            uint8_t wifi = 255;
            uint8_t deviceFocused = 255;
            uint8_t system = 255;
            uint8_t gps = 255;
            uint8_t home = 255;
            uint8_t games = 255;
            uint8_t textMessage = 255;
            uint8_t nodelist_nodes = 255;
            uint8_t nodelist_location = 255;
            uint8_t nodelist_lastheard = 255;
            uint8_t nodelist_hopsignal = 255;
            uint8_t nodelist_distance = 255;
            uint8_t nodelist_bearings = 255;
            uint8_t clock = 255;
            uint8_t chirpy = 255;
            uint8_t firstFavorite = 255;
            uint8_t lastFavorite = 255;
            uint8_t lora = 255;
        } positions;

        uint8_t frameCount = 0;
    } framesetInfo;

    struct hiddenFrames {
        bool textMessage = false;
        bool waypoint = false;
        bool wifi = false;
        bool system = false;
        bool home = false;
        bool clock = false;
#ifndef USE_EINK
        bool nodelist_nodes = false;
        bool nodelist_location = false;
#endif
#ifdef USE_EINK
        bool nodelist_lastheard = false;
        bool nodelist_hopsignal = false;
        bool nodelist_distance = false;
#endif
#if HAS_GPS
#ifdef USE_EINK
        bool nodelist_bearings = false;
#endif
        bool gps = false;
#endif
        bool lora = false;
        bool show_favorites = false;
        bool chirpy = true;
    } hiddenFrames;

    // Convert hiddenFrames to a uint32 bitmask. Bit positions are fixed per
    // frame name (see Screen.cpp).
    uint32_t packHiddenFrames() const;
    void applyHiddenFramesMask(uint32_t mask);

    /// Try to start drawing ASAP
    void setFastFramerate();

    // Sets frame up for immediate drawing
    void setFrameImmediateDraw(FrameCallback *drawFrames);

    /// callback for current alert frame
    FrameCallback alertFrame;

    /// Queue of commands to execute in doTask.
    TypedQueue<ScreenCmd> cmdQueue;
    /// Whether we are using a display
    bool useDisplay = false;
    /// Whether the display is currently powered
    bool screenOn = false;
    // Whether we are showing the regular screen (as opposed to booth screen or
    // Bluetooth PIN screen)
    bool showingNormalScreen = false;
    std::atomic<bool> textMessageFrameShown{false};
    /// Track USB power state to only wake screen on actual power state changes
    bool lastPowerUSBState = false;

    // Implementation to Adjust Brightness
    uint8_t brightness = BRIGHTNESS_DEFAULT; // H = 254, MH = 192, ML = 130 L = 103

    bool hasCompass = false;
    float compassHeading;
    uint32_t endCalibrationAt;

    /// Display device
#ifdef USE_ST7789
    ST7789Spi *dispdev;
#else
    OLEDDisplay *dispdev;
#endif

    /// UI helper for rendering to frames and switching between them
    // True if any module frame -- or the games frame, which is not a moduleFrame -- is currently
    // holding the D-pad. Shared by the input router and isInteractionBusy().
    bool anyModuleInterceptingInput();

    OLEDDisplayUi *ui;
};

} // namespace graphics

// Extern declarations for function symbols used in UIRenderer
extern std::vector<std::string> functionSymbol;
extern std::string functionSymbolString;
extern std::unique_ptr<graphics::Screen> screen;

#endif

#pragma once
#include "configuration.h"

#ifdef USE_SHARP_MEMORY_LCD

#include <OLEDDisplay.h>

class SharpMemoryDisplay final : public OLEDDisplay
{
  public:
    SharpMemoryDisplay();
    void display() override;

  protected:
    bool connect() override;
    void sendCommand(uint8_t) override {}
    int getBufferOffset() override { return 0; }

  private:
    bool vcom = true;
};

#endif

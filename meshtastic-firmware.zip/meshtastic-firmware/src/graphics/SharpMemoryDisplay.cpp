#include "SharpMemoryDisplay.h"

#ifdef USE_SHARP_MEMORY_LCD

#include "SPILock.h"
#include "concurrency/LockGuard.h"
#include <Arduino.h>
#include <SPI.h>
#include <cstring>

SharpMemoryDisplay::SharpMemoryDisplay()
{
    geometry = GEOMETRY_RAWMODE;
    displayWidth = SHARP_LCD_WIDTH;
    displayHeight = SHARP_LCD_HEIGHT;
    displayBufferSize = displayWidth * ((displayHeight + 7) / 8);
}

bool SharpMemoryDisplay::connect()
{
    pinMode(SHARP_LCD_CS, OUTPUT);
    digitalWrite(SHARP_LCD_CS, LOW); // Sharp CS is active HIGH.
    pinMode(SHARP_LCD_ENABLE, OUTPUT);
    digitalWrite(SHARP_LCD_ENABLE, HIGH);
    return true;
}

void SharpMemoryDisplay::display()
{
    if (!buffer)
        return;

    concurrency::LockGuard guard(spiLock);
    SPI.beginTransaction(SPISettings(2000000, LSBFIRST, SPI_MODE0));
    digitalWrite(SHARP_LCD_CS, HIGH);
    SPI.transfer(uint8_t(0x01 | (vcom ? 0x02 : 0)));
    vcom = !vcom;

    constexpr uint16_t bytesPerLine = SHARP_LCD_WIDTH / 8;
    uint8_t line[bytesPerLine + 2];
    for (uint16_t y = 0; y < SHARP_LCD_HEIGHT; ++y) {
        line[0] = uint8_t(y + 1);
        memset(line + 1, 0xFF, bytesPerLine);
        for (uint16_t x = 0; x < SHARP_LCD_WIDTH; ++x) {
            const uint8_t bit = uint8_t(1U << (y & 7));
            if (buffer[x + (y / 8) * SHARP_LCD_WIDTH] & bit)
                line[1 + (x / 8)] &= uint8_t(~(1U << (x & 7)));
        }
        line[bytesPerLine + 1] = 0;
        for (uint16_t i = 0; i < bytesPerLine + 2; ++i)
            SPI.transfer(line[i]);
    }
    SPI.transfer(uint8_t(0));
    digitalWrite(SHARP_LCD_CS, LOW);
    SPI.endTransaction();
}

#endif

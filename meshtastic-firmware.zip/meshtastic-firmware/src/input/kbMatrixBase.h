#pragma once
#include "configuration.h"

#include "InputBroker.h"
#include "concurrency/OSThread.h"

#if INPUTBROKER_MATRIX_TYPE == 2
// Motion-aware backlight wake-up shared with the Q10 field module.
extern volatile uint32_t q10MotionBacklightAt;
extern volatile bool q10KeyboardBacklightEnabled;
#endif

class KbMatrixBase : public Observable<const InputEvent *>, public concurrency::OSThread
{
  public:
    explicit KbMatrixBase(const char *name);

  protected:
    virtual int32_t runOnce() override;

  private:
    const char *_originName;
    bool firstTime = 1;
    int shift = 0;
    char key = 0;
    char prevkey = 0;
#if INPUTBROKER_MATRIX_TYPE == 2
    uint8_t candidateKey = 0xFF;
    uint8_t stableKey = 0xFF;
    uint32_t candidateAt = 0;
    uint32_t pressedAt = 0;
    uint32_t repeatedAt = 0;
    uint32_t lastInputAt = 0;
    bool capsLock = false;
    bool shiftComboHeld = false;
    bool backlightEnabled = true;
#endif
};

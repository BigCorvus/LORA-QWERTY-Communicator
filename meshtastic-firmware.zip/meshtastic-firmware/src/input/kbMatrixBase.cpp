#include "kbMatrixBase.h"
#include "configuration.h"
#include "mesh/Throttle.h"
#include "UptimeClock.h"

#ifdef INPUTBROKER_MATRIX_TYPE

const byte keys_cols[] = KEYS_COLS;
const byte keys_rows[] = KEYS_ROWS;

#if INPUTBROKER_MATRIX_TYPE == 1

unsigned char KeyMap[3][sizeof(keys_rows)][sizeof(keys_cols)] = {{{' ', '.', 'm', 'n', 'b', 0xb6},
                                                                  {0x0d, 'l', 'k', 'j', 'h', 0xb4},
                                                                  {'p', 'o', 'i', 'u', 'y', 0xb5},
                                                                  {0x08, 'z', 'x', 'c', 'v', 0xb7},
                                                                  {'a', 's', 'd', 'f', 'g', 0x09},
                                                                  {'q', 'w', 'e', 'r', 't', 0x1a}},
                                                                 {// SHIFT
                                                                  {':', ';', 'M', 'N', 'B', 0xb6},
                                                                  {0x0d, 'L', 'K', 'J', 'H', 0xb4},
                                                                  {'P', 'O', 'I', 'U', 'Y', 0xb5},
                                                                  {0x08, 'Z', 'X', 'C', 'V', 0xb7},
                                                                  {'A', 'S', 'D', 'F', 'G', 0x09},
                                                                  {'Q', 'W', 'E', 'R', 'T', 0x1a}},
                                                                 {// SHIFT-SHIFT
                                                                  {'_', ',', '>', '<', '"', '{'},
                                                                  {'~', '-', '*', '&', '+', '['},
                                                                  {'0', '9', '8', '7', '6', '}'},
                                                                  {'=', '(', ')', '?', '/', ']'},
                                                                  {'!', '@', '#', '$', '%', '\\'},
                                                                  {'1', '2', '3', '4', '5', 0x1a}}};
#elif INPUTBROKER_MATRIX_TYPE == 2
volatile uint32_t q10MotionBacklightAt = 0;
volatile bool q10KeyboardBacklightEnabled = true;
static constexpr char q10Letters[7][5] = {
    {'q', 'e', 'r', 'u', 'o'}, {'w', 's', 'g', 'h', 'l'}, {0, 'd', 't', 'y', 'i'},
    {'a', 'p', 0, '\r', '\b'}, {0, 'x', 'v', 'b', '$'}, {' ', 'z', 'c', 'n', 'm'},
    {'~', 0, 'f', 'j', 'k'},
};
static constexpr char q10Symbols[7][5] = {
    {'#', '2', '3', '_', '+'}, {'1', '4', '/', ':', '"'}, {0, '5', '(', ')', '-'},
    {'*', '@', 0, '\r', '\b'}, {0, '8', '?', '!', '`'}, {' ', '7', '9', ',', '.'},
    {'0', 0, '6', ';', '\''},
};
#endif

KbMatrixBase::KbMatrixBase(const char *name) : concurrency::OSThread(name)
{
    this->_originName = name;
}

int32_t KbMatrixBase::runOnce()
{
    if (!INPUTBROKER_MATRIX_TYPE) {
        // Input device is not requested.
        return disable();
    }

    if (firstTime) {
        // This is the first time the OSThread library has called this function, so do port setup
        firstTime = 0;
#if INPUTBROKER_MATRIX_TYPE == 2
        for (byte pin : keys_cols)
            pinMode(pin, INPUT);
        for (byte pin : keys_rows)
            pinMode(pin, INPUT_PULLUP);
        pinMode(Q10_KEYBOARD_BACKLIGHT, OUTPUT);
        digitalWrite(Q10_KEYBOARD_BACKLIGHT, LOW);
#else
        for (byte i = 0; i < sizeof(keys_rows); i++) {
            pinMode(keys_rows[i], OUTPUT);
            digitalWrite(keys_rows[i], HIGH);
        }
        for (byte i = 0; i < sizeof(keys_cols); i++) {
            pinMode(keys_cols[i], INPUT_PULLUP);
        }
#endif
    }

    key = 0;

#if INPUTBROKER_MATRIX_TYPE == 1
    if (INPUTBROKER_MATRIX_TYPE == 1) {
        // scan for keypresses
        for (byte i = 0; i < sizeof(keys_rows); i++) {
            digitalWrite(keys_rows[i], LOW);
            for (byte j = 0; j < sizeof(keys_cols); j++) {
                if (digitalRead(keys_cols[j]) == LOW) {
                    key = KeyMap[shift][i][j];
                }
            }
            digitalWrite(keys_rows[i], HIGH);
        }
        // debounce
        if (key != prevkey) {
            if (key != 0) {
                LOG_INPUT("Key 0x%x pressed", key);
                // reset shift now that we have a keypress
                InputEvent e = {};
                e.inputEvent = INPUT_BROKER_NONE;
                e.source = this->_originName;
                switch (key) {
                case 0x1b: // ESC
                    e.inputEvent = INPUT_BROKER_CANCEL;
                    break;
                case 0x08: // Back
                    e.inputEvent = INPUT_BROKER_BACK;
                    e.kbchar = 0;
                    break;
                case 0xb5: // Up
                    e.inputEvent = INPUT_BROKER_UP;
                    break;
                case 0xb6: // Down
                    e.inputEvent = INPUT_BROKER_DOWN;
                    break;
                case 0xb4: // Left
                    e.inputEvent = INPUT_BROKER_LEFT;
                    e.kbchar = 0;
                    break;
                case 0xb7: // Right
                    e.inputEvent = INPUT_BROKER_RIGHT;
                    e.kbchar = 0;
                    break;
                case 0x0d: // Enter
                    e.inputEvent = INPUT_BROKER_SELECT;
                    break;
                case 0x00: // nopress
                    e.inputEvent = INPUT_BROKER_NONE;
                    break;
                case 0x1a: // Shift
                    shift++;
                    if (shift > 2) {
                        shift = 0;
                    }
                    break;
                default: // all other keys
                    e.inputEvent = INPUT_BROKER_ANYKEY;
                    e.kbchar = key;
                    break;
                }
                if (e.inputEvent != INPUT_BROKER_NONE) {
                    this->notifyObservers(&e);
                }
            }
            prevkey = key;
        }

    } else {
        LOG_WARN("Unknown kb_model 0x%02x", INPUTBROKER_MATRIX_TYPE);
        return disable();
    }
#elif INPUTBROKER_MATRIX_TYPE == 2
    bool pressed[7][5] = {};
    for (uint8_t col = 0; col < 5; ++col) {
        pinMode(keys_cols[col], OUTPUT);
        digitalWrite(keys_cols[col], LOW);
        delayMicroseconds(150);
        for (uint8_t row = 0; row < 7; ++row)
            pressed[row][col] = digitalRead(keys_rows[row]) == LOW;
        pinMode(keys_cols[col], INPUT);
    }

    const bool alt = pressed[4][0];
    const bool symbol = pressed[2][0];
    const bool leftShift = pressed[6][1];
    const bool rightShift = pressed[3][2];
    const bool bothShifts = leftShift && rightShift;
    if (bothShifts && !shiftComboHeld)
        capsLock = !capsLock;
    shiftComboHeld = bothShifts;

    uint8_t physicalKey = 0xFF;
    for (uint8_t row = 0; row < 7 && physicalKey == 0xFF; ++row) {
        for (uint8_t col = 0; col < 5; ++col) {
            if (!pressed[row][col] || (row == 4 && col == 0) || (row == 2 && col == 0) ||
                (row == 6 && col == 1) || (row == 3 && col == 2))
                continue;
            physicalKey = row * 5 + col;
            break;
        }
    }

    const uint32_t now = Time::getMillis();
    if (physicalKey != candidateKey) {
        candidateKey = physicalKey;
        candidateAt = now;
    }
    if (candidateKey != stableKey && Throttle::hasElapsed(candidateAt, 20)) {
        stableKey = candidateKey;
        pressedAt = now;
        repeatedAt = now;
    } else if (candidateKey == stableKey && stableKey != 0xFF) {
        // Repetition is useful for cursor movement and deletion, but not for short taps.
        if (!Throttle::hasElapsed(pressedAt, 460) || !Throttle::hasElapsed(repeatedAt, 100))
            return 20;
        repeatedAt = now;
    } else {
        if (backlightEnabled && (!lastInputAt || Throttle::hasElapsed(lastInputAt, 8000)) &&
            (!q10MotionBacklightAt || Throttle::hasElapsed(q10MotionBacklightAt, 8000)))
            digitalWrite(Q10_KEYBOARD_BACKLIGHT, LOW);
        return 20;
    }

    if (stableKey == 0xFF)
        return 20;

    lastInputAt = now;
    if (backlightEnabled)
        digitalWrite(Q10_KEYBOARD_BACKLIGHT, HIGH);

    const uint8_t row = stableKey / 5;
    const uint8_t col = stableKey % 5;
    char chr = symbol ? q10Symbols[row][col] : q10Letters[row][col];
    InputEvent e = {};
    e.source = _originName;
    e.inputEvent = INPUT_BROKER_ANYKEY;
    if (alt && (chr == 'w' || chr == 's' || chr == 'a' || chr == 'd')) {
        e.inputEvent = (chr == 'w')   ? INPUT_BROKER_UP
                       : (chr == 's') ? INPUT_BROKER_DOWN
                       : (chr == 'a') ? INPUT_BROKER_LEFT
                                      : INPUT_BROKER_RIGHT;
    } else if (alt && chr == 'q') {
        e.kbchar = 0xE1;
    } else if (alt && chr == 'p') {
        e.kbchar = 0xE2;
    } else if (alt && chr == 'g') {
        e.inputEvent = INPUT_BROKER_GPS_TOGGLE;
    } else if (alt && chr == 'l') {
        backlightEnabled = !backlightEnabled;
        q10KeyboardBacklightEnabled = backlightEnabled;
        digitalWrite(Q10_KEYBOARD_BACKLIGHT, backlightEnabled ? HIGH : LOW);
        return 20;
    } else if (chr == '\r') {
        e.inputEvent = INPUT_BROKER_SELECT;
    } else if (chr == '\b') {
        e.inputEvent = INPUT_BROKER_BACK;
    } else if (chr == '~') {
        e.inputEvent = INPUT_BROKER_CANCEL;
    } else if (chr != 0) {
        e.kbchar = (leftShift || rightShift || capsLock) && chr >= 'a' && chr <= 'z' ? chr - 'a' + 'A' : chr;
    } else {
        return 20;
    }
    notifyObservers(&e);
    return 20;
#endif
    return 50; // Keyscan every 50msec to avoid key bounce
}

#endif // INPUTBROKER_MATRIX_TYPE
